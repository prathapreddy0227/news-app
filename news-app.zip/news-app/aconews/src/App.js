import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_KEY = '5796e22a9a702cdb7db0c7bd10af719f'; // Replace with your API key
const API_URL = 'https://gnews.io/api/v4/top-headlines';

function App() {
  const [articles, setArticles] = useState([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async (searchQuery = '') => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(API_URL, {
        params: {
          q: searchQuery,
          token: API_KEY,
        },
      });
      setArticles(response.data.articles);
    } catch (error) {
      console.error("Error fetching the news", error);
      setError("Failed to fetch news. Please try again later.");
    }
    setLoading(false);
  };

  const handleSearch = () => {
    fetchNews(query);
  };

  return (
    <div className="App">
      <header>
        <h1>ACONEWS</h1>
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search news..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button onClick={handleSearch}>Search</button>
        </div>
      </header>
      <main>
        {loading ? (
          <p className="loading">Loading...</p>
        ) : error ? (
          <p className="error">{error}</p>
        ) : (
          <div className="news-container">
            {articles.length > 0 ? (
              articles.map((article, index) => (
                <div key={index} className="news-item">
                  {article.image && <img src={article.image} alt="News" className="news-image" />}
                  <div className="news-content">
                    <h2>
                      <a href={article.url} target="_blank" rel="noopener noreferrer">
                        {article.title}
                      </a>
                    </h2>
                    <p>{article.description}</p>
                  </div>
                </div>
              ))
            ) : (
              <p>No news articles found.</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
